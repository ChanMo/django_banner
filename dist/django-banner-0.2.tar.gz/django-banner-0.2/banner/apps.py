#!/usr/bin/python
# vim: set fileencoding=utf-8 :
from django.apps import AppConfig

class BannerConfig(AppConfig):
    name = u'banner'
    verbose_name = u'轮播图'
