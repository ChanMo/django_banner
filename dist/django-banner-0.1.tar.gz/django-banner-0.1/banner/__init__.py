default_app_config = 'banner.apps.BannerConfig'

